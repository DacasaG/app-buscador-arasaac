#!/bin/bash

cd $1 && ./buscador 2>>$1/error.log
